/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasoopdanexception;

import java.lang.Math;
/**
 *
 * @author ASUS
 */
public class BangunDatar {
    
    double luas(){
        return 0;
    }
    
    double luas(int a, int b){
        return 0;
    }
    
    double keliling(){
        return 0;
    }
  
    double keliling(int a, int b){
        return 0;
    }
   
}
