/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasoopdanexception;

/**
 *
 * @author ASUS
 */
public class BangunRuang {
    
    double luaspermukaan(){
        return 0;
    }
    
    double volume(){
        return 0;
    }
    
    double luaspermukaan(int a, int b, int c){
        return 0;
    }
    
    double volume(int a, int b, int c){
        return 0;
    }
    
    double luaspermukaan(int a, int b){
        return 0;
    }
    
    double volume(int a, int b){
        return 0;
    }
}
